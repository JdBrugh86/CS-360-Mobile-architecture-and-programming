package com.cs360.jbrughinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;

import androidx.annotation.Nullable;

public class InvDatabaseHelper extends SQLiteOpenHelper {

    public static final String invDbName = "Inv.db";

    public InvDatabaseHelper(@Nullable Context context) {
        super(context, invDbName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table items(itemName TEXT primary key, qty INTEGER, safetyStock INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists items");
    }

    public void createItem(String itemName, int qty, int safetyStock){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("itemName", itemName);
        contentValues.put("qty", qty);
        contentValues.put("safetyStock", safetyStock);
        db.insert("items", null, contentValues);
    }

}
