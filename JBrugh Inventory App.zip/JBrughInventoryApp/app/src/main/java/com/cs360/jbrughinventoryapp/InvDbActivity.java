package com.cs360.jbrughinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class InvDbActivity extends AppCompatActivity {
    private Button mDeleteItemButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inv_db);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button mAddItemButton = findViewById(R.id.add_item_button);
        mDeleteItemButton = findViewById(R.id.delete_item_button);

        mAddItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), ItemEntryActivity.class);
            startActivity(intent);
        });
    }
}
