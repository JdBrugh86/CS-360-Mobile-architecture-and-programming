package com.cs360.jbrughinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ItemEntryActivity extends AppCompatActivity {
    InvDatabaseHelper invDatabaseHelper;
    private TextView mItemName;
    private TextView mQuantity;
    private TextView mSafetyStock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_entry);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        invDatabaseHelper = new InvDatabaseHelper(this);
        Button mEnterItemButton = findViewById(R.id.enter_item_button);
        mItemName = findViewById(R.id.item_name_enter);
        mQuantity = findViewById(R.id.entered_quantity);
        mSafetyStock = findViewById(R.id.safety_stock_quantity);

        mEnterItemButton.setOnClickListener(v -> {
            String name = mItemName.getText().toString();
            String qty = mQuantity.getText().toString();
            String ssQty = mSafetyStock.getText().toString();
            int qtyInt = Integer.parseInt(qty);
            int ssQtyInt = Integer.parseInt(ssQty);

            //fixMe: This check doesn't work
            if (name.isBlank() || qty.isBlank() || ssQty.isBlank()) {
                Toast.makeText(ItemEntryActivity.this, "All fields are required.", Toast.LENGTH_SHORT).show();
            }

            else {
                invDatabaseHelper.createItem(name, qtyInt, ssQtyInt);
                Intent intent = new Intent(getApplicationContext(), InvDbActivity.class);
                startActivity(intent);
            }

        });
    }
}