package com.cs360.jbrughinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private TextView mUsernameText;
    private TextView mPasswordText;
    LoginDatabaseHelper loginDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        loginDatabaseHelper = new LoginDatabaseHelper(this);
        Button mLoginButton = findViewById(R.id.login_button);
        Button mRegisterButton = findViewById(R.id.register_button);
        mUsernameText = findViewById(R.id.username_input);
        mPasswordText = findViewById(R.id.password_input);

        mLoginButton.setOnClickListener(v -> {
            String username = mUsernameText.getText().toString();
            String password = mPasswordText.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "All fields are required.", Toast.LENGTH_SHORT).show();
            }

            else {
                Boolean checkCredentials = loginDatabaseHelper.checkPassword(username, password);

                if (checkCredentials == true){
                    Toast.makeText(MainActivity.this, "Login Successful.", Toast.LENGTH_SHORT).show();
                    Intent intent  = new Intent(getApplicationContext(), InvDbActivity.class);
                    startActivity(intent);
                }

                else {
                    Toast.makeText(MainActivity.this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mRegisterButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }
}
