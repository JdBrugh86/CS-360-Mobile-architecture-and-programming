package com.cs360.jbrughinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RegisterActivity extends AppCompatActivity {
    private TextView mNewUsernameText;
    private TextView mNewPasswordText;
    private TextView mConfirm_password_input;
    LoginDatabaseHelper loginDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        loginDatabaseHelper = new LoginDatabaseHelper(this);
        Button mRegisterNewUserButton = findViewById(R.id.register_new_user_button);
        mNewUsernameText = findViewById(R.id.new_username_input);
        mNewPasswordText = findViewById(R.id.new_password_input);
        mConfirm_password_input = findViewById(R.id.confirm_password_input);

        mRegisterNewUserButton.setOnClickListener(view -> {
            String newUsername = mNewUsernameText.getText().toString();
            String newPassword = mNewPasswordText.getText().toString();
            String confirmPassword = mConfirm_password_input.getText().toString();

            if (newUsername.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "All fields are required", Toast.LENGTH_SHORT).show();
            }

            else {
                if (newPassword.equals(confirmPassword)) {
                    Boolean checkName = loginDatabaseHelper.checkUsername(newUsername);

                    if (checkName == false) {
                        Boolean insert = loginDatabaseHelper.insertData(newUsername, newPassword);

                        if (insert == true) {
                            Toast.makeText(RegisterActivity.this, "Registration Successful.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                            startActivity(intent);
                        }

                        else {
                            Toast.makeText(RegisterActivity.this, "Registration Failed.", Toast.LENGTH_SHORT).show();
                        }
                    }

                    else {
                        Toast.makeText(RegisterActivity.this, "User already exists. Please login.", Toast.LENGTH_SHORT).show();
                    }
                }

                else {
                    Toast.makeText(RegisterActivity.this, "Invalid Password.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}